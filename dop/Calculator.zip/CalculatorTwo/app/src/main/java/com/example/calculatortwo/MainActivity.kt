package com.example.calculatortwo

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.calculatortwo.R.id.buttonClear


class MainActivity : AppCompatActivity() {


    private var signn: String = ""


    private lateinit var inputOne : TextView
    private lateinit var inputTwo : TextView
    private lateinit var sign : TextView
    private lateinit var result : TextView


    private lateinit var plus : Button
    private lateinit var minus : Button
    private lateinit var multiply : Button
    private lateinit var division : Button

    private lateinit var equals : Button
    private lateinit var clear : Button


    private lateinit var num0 : Button
    private lateinit var num1 : Button
    private lateinit var num2 : Button
    private lateinit var num3 : Button
    private lateinit var num4 : Button
    private lateinit var num5 : Button
    private lateinit var num6 : Button
    private lateinit var num7 : Button
    private lateinit var num8 : Button
    private lateinit var num9 : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputOne = findViewById(R.id.inputOne)
        inputTwo = findViewById(R.id.inputTwo)
        sign = findViewById(R.id.sign)
        result = findViewById(R.id.result)


        plus = findViewById(R.id.plus)
        plus.setOnClickListener {
            if(!result.text.toString().isBlank()){
                inputOne.setText(result.text.toString())
                sign.setText("+")
                result.setText("")
            }else{
                sign.setText("+")
            }
        }
        minus = findViewById(R.id.minus)
        minus.setOnClickListener {
            if(!result.text.toString().isBlank()){
                inputOne.setText(result.text.toString())
                sign.setText("-")
                result.setText("")
            }else{
                sign.setText("-")
            }
        }
        multiply = findViewById(R.id.multiply)
        multiply.setOnClickListener {
            if(!result.text.toString().isBlank()){
                inputOne.setText(result.text.toString())
                sign.setText("*")
                result.setText("")
            }else{
                sign.setText("*")
            }
        }
        division = findViewById(R.id.division)
        division.setOnClickListener {
            if(!result.text.toString().isBlank()){
                inputOne.setText(result.text.toString())
                sign.setText("/")
                result.setText("")
            }else{
                sign.setText("/")
            }
        }

        clear = findViewById(R.id.clear)
        clear.setOnClickListener {
            inputOne.setText("")
            inputTwo.setText("")
            sign.setText("")
            result.setText("")

        }


        equals = findViewById(R.id.equals)
        equals.setOnClickListener {
            if(inputOne.text.toString().isBlank() && inputTwo.text.toString().isBlank()){
                inputOne.error = "Ошибочка!!!"
                inputTwo.error = "Ошибочка!!!"
            }else{
                signn = sign.text.toString()

                if(signn == "+") {
                    var num1 : Int = inputOne.text.toString().toInt()
                    var num2 : Int = inputTwo.text.toString().toInt()
                    var res = num1+num2
                    result.setText(res.toString())
                    inputOne.setText("")
                    inputTwo.setText("")
                    sign.setText("")

                }
                if(signn == "-") {
                    var num1 : Int = inputOne.text.toString().toInt()
                    var num2 : Int = inputTwo.text.toString().toInt()
                    var res = num1-num2
                    result.setText(res.toString())
                    inputOne.setText("")
                    inputTwo.setText("")
                    sign.setText("")
                }
                if(signn == "/") {
                    var num1 : Int = inputOne.text.toString().toInt()
                    var num2 : Int = inputTwo.text.toString().toInt()
                    if(num2!=0){
                        var res = num1/num2
                        result.setText(res.toString())
                        inputOne.setText("")
                        inputTwo.setText("")
                        sign.setText("")
                    }else{
                        result.error = "Ну ты мать даёшь!"
                    }

                }
                if(signn == "*") {
                    var num1 : Int = inputOne.text.toString().toInt()
                    var num2 : Int = inputTwo.text.toString().toInt()
                    var res = num1*num2
                    result.setText(res.toString())
                    inputOne.setText("")
                    inputTwo.setText("")
                    sign.setText("")
                }
            }
        }

        num0 = findViewById(R.id.num0)
        num0.setOnClickListener {
            if(sign.text.toString().isBlank()){
                inputOne.setText(inputOne.text.toString() + "0")
            }else{
                inputTwo.setText(inputTwo.text.toString() + "0")
            }
        }

        num1 = findViewById(R.id.num1)
        num1.setOnClickListener {
            if(sign.text.toString().isBlank()){
                inputOne.setText(inputOne.text.toString() + "1")
            }else{
                inputTwo.setText(inputTwo.text.toString() + "1")
            }
        }

        num2 = findViewById(R.id.num2)
        num2.setOnClickListener {
            if(sign.text.toString().isBlank()){
                inputOne.setText(inputOne.text.toString() + "2")
            }else{
                inputTwo.setText(inputTwo.text.toString() + "2")
            }
        }

        num3 = findViewById(R.id.num3)
        num3.setOnClickListener {
            if(sign.text.toString().isBlank()){
                inputOne.setText(inputOne.text.toString() + "3")
            }else{
                inputTwo.setText(inputTwo.text.toString() + "3")
            }
        }

        num4 = findViewById(R.id.num4)
        num4.setOnClickListener {
            if(sign.text.toString().isBlank()){
                inputOne.setText(inputOne.text.toString() + "4")
            }else{
                inputTwo.setText(inputTwo.text.toString() + "4")
            }
        }

        num5 = findViewById(R.id.num5)
        num5.setOnClickListener {
            if(sign.text.toString().isBlank()){
                inputOne.setText(inputOne.text.toString() + "5")
            }else{
                inputTwo.setText(inputTwo.text.toString() + "5")
            }
        }

        num6 = findViewById(R.id.num6)
        num6.setOnClickListener {
            if(sign.text.toString().isBlank()){
                inputOne.setText(inputOne.text.toString() + "6")
            }else{
                inputTwo.setText(inputTwo.text.toString() + "6")
            }
        }

        num7 = findViewById(R.id.num7)
        num7.setOnClickListener {
            if(sign.text.toString().isBlank()){
                inputOne.setText(inputOne.text.toString() + "7")
            }else{
                inputTwo.setText(inputTwo.text.toString() + "7")
            }
        }

        num8 = findViewById(R.id.num8)
        num8.setOnClickListener {
            if(sign.text.toString().isBlank()){
                inputOne.setText(inputOne.text.toString() + "8")
            }else{
                inputTwo.setText(inputTwo.text.toString() + "8")
            }
        }

        num9 = findViewById(R.id.num9)
        num9.setOnClickListener {
            if(sign.text.toString().isBlank()){
                inputOne.setText(inputOne.text.toString() + "9")
            }else{
                inputTwo.setText(inputTwo.text.toString() + "9")
            }
        }

    }
}