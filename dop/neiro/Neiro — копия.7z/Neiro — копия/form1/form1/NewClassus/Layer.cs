﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace form1.NewClassus
{
    abstract class Layer
    {
        //поля
        protected string name_Layer;
        string pathDirWeights;
        string pathFileWeights;
        protected int numofneurons;
        protected int numofprevneurons;
        protected const double learningrate = 0.005d;
        protected const double momentum = 0.05d;
        protected double[,] lastdeltaweights;
        Neuron[] _neurons;

        //свойства

        public Neuron[] Neurons { get => _neurons; set => _neurons = value; }

        //Входные данные
        public double[] inputData
        {
            set
            {
                for (int i = 0; i < Neurons.Length; ++i)
                {
                    Neurons[i].Inputs = value;
                    Neurons[i].Activator(Neurons[i].Inputs, Neurons[i].Weights);
                }
            }
        }

        // Конструтктор

        protected Layer(int non, int nopn, TypeNeuron nt, string nm_Layer)
        {
            int i, j;
            numofneurons = non;
            numofprevneurons = nopn;
            Neurons = new Neuron[non];
            name_Layer = nm_Layer;
            pathDirWeights = AppDomain.CurrentDomain.BaseDirectory + "memory\\";
            pathFileWeights = pathDirWeights + name_Layer;

            double[,] Weights;

            if(File.Exists(pathFileWeights))
            {
                Weights = WeightInitialize(MemoryMode.GET, pathFileWeights);
            }
            else
            {
                Directory.CreateDirectory(pathDirWeights);
                Weights = WeightInitialize(MemoryMode.INIT, pathFileWeights);
            }

            lastdeltaweights = new double[non, nopn + 1];


        }

        //методы
        //15-70-35-10 логическая функция

        public double [,] WeightInitialize(MemoryMode mm, string path)
        {
            int i, j;
            char[] delta = new char[] { ';', ' ' };
            string tmpStr;
            string[] tmpStrWeights;

            switch(mm)
            {
                case MemoryMode.GET:


                case MemoryMode.SET:


                case MemoryMode.INIT:
                    


            }
        }
    }
}
