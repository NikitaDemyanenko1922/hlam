﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace form1.NewClassus
{
    class NeuroNetwork
    {
        //Поля
        private InputLayer inputLayer = null;
        //private HiddenLayer1 = new HiddenLayer1(70, 15, NeuronType Hidden,)
        //Конструктор
        NeuroNetwork()
        {

        }
    }
}
