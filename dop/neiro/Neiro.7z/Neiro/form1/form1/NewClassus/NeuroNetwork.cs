﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace form1.NewClassus
{
    class NeuroNetwork
    {
        //Поля
        private InputLayer input_Layer = null;
        private HiddenLayer1 hidden_Layer1 = new HiddenLayer1(70, 15, TypeNeuron.Hidden, nameof(hidden_Layer1));
        private HiddenLayer1 hidden_Layer2 = new HiddenLayer1(70, 15, TypeNeuron.Hidden, nameof(hidden_Layer2));
        private OutputLayer output_Layer = new OutputLayer(70, 15, TypeNeuron.Output, nameof(output_Layer));


        public double[] fact = new double[10];

        public double e_error_avr;
        public double E_error_avr { get => e_error_avr; set => e_error_avr = value; }
        public event EventHandler<EventArgs> UpDateChart;
        public NeuroNetwork(NetworkMode nm) => input_Layer = new InputLayer(nm);



        public void ForvardPass(NetworkMode net, double[] netInput)
        {
            net.hidden_Layer1.Data = netInput;
            net.hidden_Layer1.Recognize(null, net.hidden_layer2);
            net.hidden_Layer2.Recognize(null, net.output_layer);
            net.output_Layer.Recognize(net, null);
        }
    }
}
