﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace form1.NewClassus
{
    class NeuroNetwork
    {
        //Поля
        private InputLayer input_Layer = null;
        private HiddenLayer hidden_Layer1 = new HiddenLayer(70, 15, TypeNeuron.HiddenNeuron, nameof(hidden_Layer1));
        private HiddenLayer hidden_Layer2 = new HiddenLayer(35, 70, TypeNeuron.HiddenNeuron, nameof(hidden_Layer2));
        private OutputLayer output_Layer = new OutputLayer(10, 35, TypeNeuron.OutputNeuron, nameof(output_Layer));


        public double[] fact = new double[10];

        public double e_error_avr;
        public double E_error_avr { get => e_error_avr; set => e_error_avr = value; }
        public event EventHandler<EventArgs> UpDateChart;

        public NeuroNetwork(NetworkMode nm) { } //=> input_Layer = new InputLayer(nm, E_error_avr);

        /*public void Train
        {

        }
         */
        public void ForwardPass(NetworkMode net, double[] netInput)
        {
            net.hidden_Layer1.inputData = netInput;
            net.hidden_Layer1.Recognize(null, net.hidden_layer2);
            net.hidden_Layer2.Recognize(null, net.output_layer);
            net.output_Layer.Recognize(net, null);
        }
    }
}
