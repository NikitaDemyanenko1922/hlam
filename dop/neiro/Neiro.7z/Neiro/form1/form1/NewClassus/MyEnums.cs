﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace form1.NewClassus
{
    enum NetworkMode { TrainNeuron, TestNeuron, DemoNeuron }
    //Тип нейронов
    enum TypeNeuron { HiddenNeuron, OutputNeuron }
    enum MemoryMode { GET, SET, INIT }
}

