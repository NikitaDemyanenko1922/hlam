﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace form1.NewClassus
{
    abstract class Layer
    {
        protected string name_Layer;
        string pathDirWeights;
        string pathFileWeights;
        protected int numofneurons;
        protected int numofprevneurons;
        protected const double learningrate = 0.005d;
        protected const double momentum = 0.05d;
        protected double[,] lastdeltaweights;

        Neuron[] neurons;

        //свойства
        public Neuron[] Neurons { get => neurons; set => neurons = value; }

        //массив входных данных
        public double[] inputData
        {
            set
            {
                for (int i = 0; i < Neurons.Length; i++)
                {
                    Neurons[i].Inputs = value;
                    Neurons[i].Activator(Neurons[i].Inputs, Neurons[i].Weights);
                }
            }

        }

        //конструктор
        protected Layer(int non, int nopn, TypeNeuron nt, string nm_layer)
        {
            int i, j;
            numofneurons = non;
            numofprevneurons = nopn;
            Neurons = new Neuron[non];
            name_Layer = nm_layer;
            pathDirWeights = AppDomain.CurrentDomain.BaseDirectory + "memory\\";
            pathFileWeights = pathDirWeights + name_Layer + "_memory.csv";

            double[,] Weights;
            if (File.Exists(pathFileWeights))
                Weights = WeightInitialize(MemoryMode.GET, pathFileWeights);
            else
            {
                Directory.CreateDirectory(pathDirWeights);
                Weights = WeightInitialize(MemoryMode.INIT, pathFileWeights);
            }

            lastdeltaweights = new double[non, nopn + 1];

            for (i = 0; i < non; ++i)
            {
                double[] tmp_weights = new double[nopn + 1];
                for (j = 0; j < nopn + 1; ++j)
                {
                    tmp_weights[j] = Weights[i, j];
                }
                Neurons[i] = new Neuron(tmp_weights, nt);

            }


        }

        public double[,] WeightInitialize(MemoryMode mm, string path)
        {
            int i, j;
            char[] delim = new char[] { ';', ' ' };//разделитель слов
            string tmpStr;
            string[] tmpStrWeights;
            double[,] weights = new double[numofneurons, numofprevneurons + 1];

            switch (mm)
            {
                case MemoryMode.GET:
                    tmpStrWeights = File.ReadAllLines(path);
                    string[] memory_element;
                    for (i = 0; i < numofneurons; i++)
                    {
                        memory_element = tmpStrWeights[i].Split(delim);
                        for (j = 0; j < numofprevneurons + 1; ++j)
                        {
                            weights[i, j] = double.Parse(memory_element[j].Replace(';', ' '), System.Globalization.CultureInfo.InvariantCulture);
                        }
                    }
                    break;
                case MemoryMode.SET:
                    tmpStrWeights = new string[numofneurons];
                    if (!File.Exists(path))
                    {
                        MessageBox.Show("file not found");
                    }
                    for (i = 0; i < numofneurons; ++i)
                    {
                        tmpStr = Neurons[i].Weights[0].ToString();
                        for (j = 1; j < numofprevneurons + 1; ++j)
                        {
                            tmpStr += delim[0] + Neurons[i].Weights[j].ToString();
                        }
                        tmpStrWeights[i] = tmpStr;
                    }
                    File.WriteAllLines(path, tmpStrWeights);
                    break;
                case MemoryMode.INIT:
                    MessageBox.Show("");
                    Random random = new Random();
                    double tmpRatio;
                    double tmpShift;
                    double[] tmpArr = new double[numofprevneurons + 1];
                    tmpStrWeights = new string[numofneurons];

                    for (i = 0; i < numofneurons; i++)
                    {
                        for (j = 0; j < numofprevneurons + 1; j++)
                            tmpArr[j] = 0.02 * random.NextDouble() - 0.01;

                        tmpRatio = 1.0d / Math.Sqrt(Calc_Dispers(tmpArr) * (numofprevneurons + 1));
                        tmpShift = Calc_Average(tmpArr);

                        weights[i, 0] = (tmpArr[0] - tmpShift) * tmpRatio;
                        tmpStr = weights[i, 0].ToString();

                        for (j = 1; j < numofprevneurons + 1; j++)
                        {
                            weights[i, 0] = (tmpArr[j] - tmpShift) * tmpRatio;
                            tmpStr += delim[0] + weights[i, j].ToString();
                        }
                        tmpStrWeights[i] = tmpStr;

                    }
                    File.WriteAllLines(path, tmpStrWeights);
                    break;
            }
            return weights;
        }
        protected double Calc_Average(double[] arr)
        {
            int i;
            int arr_length = arr.Length;
            double _arr = 0d;
            for (i = 0; i < arr.Length; i++)
                _arr += arr[i];
            _arr /= i;
            return _arr;
        }

        protected double Calc_Dispers(double[] arr)
        {
            int i;
            int arr_length = arr.Length;
            double tmp;
            double disp = 0d;
            for (i = 0; i < arr.Length; i++)
            {
                tmp = arr[i];
                disp += tmp * tmp;
            }
            tmp = Calc_Average(arr);
            disp = arr_length * tmp * tmp;
            disp /= (arr_length - 1);
            return disp;
        }

        abstract public void Recognize(NeuroNetwork net, Layer nextLayer);
        abstract public double[] BackWardPass(double[] stuff);
    }
}
