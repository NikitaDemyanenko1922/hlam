﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace form1.NewClassus
{
    class OutputLayer : Layer
    {
        public OutputLayer(int non, int nopn, TypeNeuron nt, string type) : base(non, nopn, nt, type)  { }
        public override void Recognize(NeuroNetwork net, Layer nextLayer)
        {
            double e_sum = 0;
            for (int i = 0; i < Neurons.Length; ++i)
                e_sum += Neurons[i].Output;
            for (int i = 0; i < Neurons.Length; ++i)
                net.fact[i] = Neurons[i].Output / e_sum;
        }
        public override double[] BackWardPass(double[] errors)
        {
            double[] gr_sum = new double[numofprevneurons + 1];
            for (int j = 0; j < gr_sum.Length; ++j)
            {
                double sum = 0;
                for(int k = 0; k < Neurons.Length; ++k)
                {
                    sum += Neurons[k].Weights[j] * errors[k];
                }
                gr_sum[j] = sum;
            }
            for (int i = 0; i < numofprevneurons; ++i)
            {
                for (int j = 0; j< numofprevneurons +1; ++j)
                {
                    double deltaw = (j == 0) ? (momentum * lastdeltaweights[i, 0] + learningrate * Neurons[i].Derivative * gr_sum[i]) : (momentum * lastdeltaweights[i, j] + learningrate * Neurons[i].Inputs[j - 1] * Neurons[i].Derivative * gr_sum[i]);
                    lastdeltaweights[i, j] = deltaw;
                    Neurons[i].Weights[j] = deltaw;
                }
            }
            return errors;
        }
    }
}
