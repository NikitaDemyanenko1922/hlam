﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace form1.NewClassus
{
    class InputLayer
    {
        double numofneurons;
        Neuron[] neurons;

        public InputLayer(double num, Neuron[] neurons)
        {
            this.numofneurons = num;
            this.neurons = neurons;
        }
    }
}
